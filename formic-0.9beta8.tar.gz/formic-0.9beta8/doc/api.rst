API
===

:mod:`formic` Package
---------------------

.. automodule:: formic.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`formic` Module
--------------------

.. automodule:: formic.formic
    :members:
    :undoc-members:
    :show-inheritance:


:mod:`command` Module
---------------------

.. automodule:: formic.command
    :members:
    :undoc-members:
    :show-inheritance:
