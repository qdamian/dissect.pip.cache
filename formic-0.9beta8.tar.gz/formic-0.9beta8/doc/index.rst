Formic Home Page
================

.. toctree::
   :maxdepth: 1

   installation
   usage
   globs
   api

.. include:: ../README.rst